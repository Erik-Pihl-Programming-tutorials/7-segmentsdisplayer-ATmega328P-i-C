/********************************************************************************
* display.h: Inneh�ller drivrutiner f�r tv� 7-segmentsdisplayer anslutna till
*            till PORTD0 - PORTD6 (pin 0 - 6), som kan visa tv� siffror i bin�r,
*            decimal eller hexadecimal form. Matningssp�nningen f�r respektive
*            7-segmentsdisplay genereras fr�n PORTD7 (pin 7) respektive
*            PORTC3 (pin A3), d�r l�g signal medf�r t�nd display, d� displayerna
*            har gemensam katod.
********************************************************************************/
#include "display.h"

/********************************************************************************
* Makrodefinitioner:
********************************************************************************/
#define DISPLAY1_CATHODE PORTD7 /* Katod f�r display 1. */
#define DISPLAY2_CATHODE PORTC3 /* Katod f�r display 2. */

#define DISPLAY1_ON  PORTD &= ~(1 << DISPLAY1_CATHODE) /* T�nder display 1. */
#define DISPLAY2_ON  PORTC &= ~(1 << DISPLAY2_CATHODE) /* T�nder display 2. */
#define DISPLAY1_OFF PORTD |= (1 << DISPLAY1_CATHODE)  /* Sl�cker display 1. */
#define DISPLAY2_OFF PORTC |= (1 << DISPLAY2_CATHODE)  /* Sl�cker display 2. */

#define OFF 0x00   /* Bin�rkod f�r sl�ckning av 7-segmentsdisplay. */
#define ZERO 0x3F  /* Bin�rkod f�r utskrift av heltalet 0 p� 7-segmentsdisplay. */
#define ONE 0x06   /* Bin�rkod f�r utskrift av heltalet 1 p� 7-segmentsdisplay. */
#define TWO 0x5B   /* Bin�rkod f�r utskrift av heltalet 2 p� 7-segmentsdisplay. */
#define THREE 0x4F /* Bin�rkod f�r utskrift av heltalet 3 p� 7-segmentsdisplay. */
#define FOUR 0x66  /* Bin�rkod f�r utskrift av heltalet 4 p� 7-segmentsdisplay. */
#define FIVE 0x6D  /* Bin�rkod f�r utskrift av heltalet 5 p� 7-segmentsdisplay. */
#define SIX 0x7D   /* Bin�rkod f�r utskrift av heltalet 6 p� 7-segmentsdisplay. */
#define SEVEN 0x07 /* Bin�rkod f�r utskrift av heltalet 7 p� 7-segmentsdisplay. */
#define EIGHT 0x7F /* Bin�rkod f�r utskrift av heltalet 8 p� 7-segmentsdisplay. */
#define NINE 0x6F  /* Bin�rkod f�r utskrift av heltalet 9 p� 7-segmentsdisplay. */
#define A 0x77     /* Bin�rkod f�r utskrift av heltalet 0xA (10) p� 7-segmentsdisplay. */
#define B 0x7C     /* Bin�rkod f�r utskrift av heltalet 0xB (11) p� 7-segmentsdisplay. */
#define C 0x39     /* Bin�rkod f�r utskrift av heltalet 0xC (12) p� 7-segmentsdisplay. */
#define D 0x5E     /* Bin�rkod f�r utskrift av heltalet 0xD (13) p� 7-segmentsdisplay. */
#define E 0x79     /* Bin�rkod f�r utskrift av heltalet 0xE (14) p� 7-segmentsdisplay. */
#define F 0x71     /* Bin�rkod f�r utskrift av heltalet 0xF (15) p� 7-segmentsdisplay. */

/********************************************************************************
* display_digit: Enumeration f�r selektion av de olika displayerna.
********************************************************************************/
enum display_digit
{
   DISPLAY_DIGIT1, /* Display 1, som visar tiotal. */
   DISPLAY_DIGIT2  /* Display 2, som visar ental. */
};

/********************************************************************************
* Statiska funktioner:
********************************************************************************/
static inline void display_update_output(const uint8_t digit);
static inline uint8_t display_get_binary_code(const uint8_t digit);

/********************************************************************************
* Statiska variabler (tempor�rt ignorerade vid kompilering):
*
*   - number : Talet som skrivs ut p� displayerna.
*   - digit1 : Tiotalet som skrivs ut p� display 1.
*   - digit2 : Entalet som skrivs ut p� display 2. 
*   - radix  : Talbas (default = 10, dvs. decimal form).
*   - max_val: Maxv�rde f�r tal p� 7-segmentsdisplayerna (beror p� talbasen).
*
*   - count_direction: Indikerar r�kningsriktning, d�r default �r uppr�kning.
*   - current_digit  : Indikerar vilken av aktuellt tals siffror som skrivs ut
*                      p� aktiverad 7-segmentsdisplay, d�r default �r tiotalet 
*                      p� display 1.
*
*   - timer_digit      : Timerkrets f�r att skifta displayer (Timer 1).
*   - timer_count_speed: Timerkrets f�r uppr�kning av heltal (Timer 2).
********************************************************************************/
#if 0 /* Ta bort denna rad samt #endif nedan f�r att definiera variablerna. */
static uint8_t number = 0;   
static uint8_t digit1 = 0;   
static uint8_t digit2 = 0;   
static uint8_t radix = 10;   
static uint8_t max_val = 99; 

static enum display_count_direction count_direction = DISPLAY_COUNT_DIRECTION_UP;
static enum display_digit current_digit = DISPLAY_DIGIT1;

static struct timer timer_digit;       
static struct timer timer_count_speed; 
#endif /* Ta bort denna rad samt #if 0 ovan f�r att definiera variablerna. */

/********************************************************************************
* display_update_output: Skriver ny siffra till aktiverad 7-segmentsdisplay.
********************************************************************************/
static inline void display_update_output(const uint8_t digit)
{
   PORTD &= (1 << DISPLAY1_CATHODE);
   PORTD |= display_get_binary_code(digit);
   return;
}

/********************************************************************************
* display_get_binary_code: Returnerar bin�rkod f�r angivet heltal 0 - 15 f�r
*                          utskrift p� 7-segmentsdisplayer. Vid felaktigt
*                          angivet heltal (�ver 15) returneras bin�rkod f�r
*                          sl�ckning av 7-segmentsdisplayer.
*
*                          - digit: Heltal vars bin�rkod ska returneras.
********************************************************************************/
static inline uint8_t display_get_binary_code(const uint8_t digit)
{
   if (digit == 0)       return ZERO;
   else if (digit == 1)  return ONE;
   else if (digit == 2)  return TWO;
   else if (digit == 3)  return THREE;
   else if (digit == 4)  return FOUR;
   else if (digit == 5)  return FIVE;
   else if (digit == 6)  return SIX;
   else if (digit == 7)  return SEVEN;
   else if (digit == 8)  return EIGHT;
   else if (digit == 9)  return NINE;
   else if (digit == 10) return A;
   else if (digit == 11) return B;
   else if (digit == 12) return C;
   else if (digit == 13) return D;
   else if (digit == 14) return E;
   else if (digit == 15) return F;
   else                  return OFF;
}